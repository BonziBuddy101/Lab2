public class RobotTest  {

  public static void main(String[]args) {
    
    
      Lab2.cleanSquare();
      Draw.pauseUntilMouse();
      Lab2.darkenComb();
      Draw.pauseUntilMouse();
      Lab2.makeCheckered();

  

}
}