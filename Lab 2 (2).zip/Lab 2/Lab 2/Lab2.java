public class Lab2
{
  public static void cleanSquare()
  {
    Robot.load("square.txt");
    Robot.setDelay(0.1);
    while (Robot.frontIsClear()){
        if (Robot.onDark()){
        Robot.makeLight();
        Robot.move();
       } else {
           Robot.move();
        }
    } 
    if (Robot.frontIsClear()==false){
        Robot.turnLeft();
    }
    while (Robot.frontIsClear()){
        if (Robot.onDark()){
        Robot.makeLight();
        Robot.move();
       } else {
           Robot.move();
        }
    } 
    if (Robot.frontIsClear()==false){
        Robot.turnLeft();
    }
    while (Robot.frontIsClear()){
        if (Robot.onDark()){
        Robot.makeLight();
        Robot.move();
       } else {
           Robot.move();
        }
    } 
    if (Robot.frontIsClear()==false){
        Robot.turnLeft();
    }
    while (Robot.frontIsClear()){
        if (Robot.onDark()){
        Robot.makeLight();
        Robot.move();
       } else {
           Robot.move();
        }
    } 
    
    //INSERT CODE HERE
  }
  
  public static void darkenComb()
  {
    Robot.load("comb.txt");
    Robot.setDelay(0.05);
    Lab2.oneLine();
    Lab2.oneLine();
    Lab2.oneLine();
    Lab2.oneLine();
    Lab2.oneLine();
    //INSERT CODE HERE
  }
  
  public static void makeCheckered()
  {
    Robot.load("blank.txt");
    Robot.setDelay(0.05);
    Lab2.oneCheckeredLine();
    if(Robot.onDark()==true){
        Lab2.turnRight();
        Robot.move();
        Robot.move();
        Robot.turnLeft();
    }
    
    //INSERT CODE HERE
    
   }
  
  public static void turnRight()
  {
     Robot.turnLeft();
     Robot.turnLeft();
     Robot.turnLeft();
      
  }
  
  public static void turnAround()
  {
      Robot.turnLeft();
      Robot.turnLeft();
      
  }
  
  public static void oneLine()
  {
    Lab2.turnRight();
    Robot.makeDark();
    while (Robot.frontIsClear())
    {
        Robot.move();
        Robot.makeDark();
    }
    Lab2.turnAround();
    while (Robot.frontIsClear())
    {
        Robot.move();
    }
    Lab2.turnRight();
    if (Robot.frontIsClear())
    {
     Robot.move();
     Robot.makeDark();
     Robot.move();
     }
  }
  
  public static void oneCheckeredLine()
  {
      while (Robot.frontIsClear()) { 
        if (Robot.onDark()==false){ 
          Robot.makeDark();
        } else {
          Lab2.turnRight();
          Robot.move();
          Robot.move();
          Robot.turnLeft();
        }
        if (Robot.frontIsClear()==true) {
         Robot.move();
         if (Robot.frontIsClear()==true) {
             Robot.move();
          } else {
              Lab2.turnRight();
              Robot.move();
              Lab2.turnRight();
            }
        } else {
            Lab2.turnRight();
            Robot.move();
            Lab2.turnRight();
        }
    }
   }
}